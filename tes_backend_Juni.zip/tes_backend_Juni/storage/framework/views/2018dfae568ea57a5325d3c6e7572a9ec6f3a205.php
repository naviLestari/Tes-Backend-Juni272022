

<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">ADD Customer (Page Create)</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('mcustomer')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label>Name</label></br>
        <input type="text" name="nama" id="nama" class="form-control"></br>
        <label>Alamat</label></br>
        <input type="text" name="alamat" id="alamat" class="form-control"></br>
        <label>Tanggal Lahir</label></br>        
        <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control"></br>
        
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mcustomer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_backend_Juni\resources\views/mcustomer/create.blade.php ENDPATH**/ ?>