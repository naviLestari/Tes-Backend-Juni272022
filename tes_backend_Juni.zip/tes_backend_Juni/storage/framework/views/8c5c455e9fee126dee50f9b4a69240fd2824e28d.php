
<?php $__env->startSection('content'); ?>
 
<div class="card">
  <div class="card-header">EDIT PAGE</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('mcustomer/' .$mcustomer2->id)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($mcustomer2->id); ?>" id="id" />
        <label>Nama</label></br>
        <input type="text" name="nama" id="nama" value="<?php echo e($mcustomer2->nama); ?>" class="form-control"></br>
        <label>Alamat</label></br>
        <input type="text" name="alamat" id="alamat" value="<?php echo e($mcustomer2->alamat); ?>" class="form-control"></br>
        <label>Tanggal Lahir</label></br>
        <input type="date" name="tanggal_lahir" id="tanggal_lahir" value="<?php echo e($mcustomer2->tanggal_lahir); ?>" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mcustomer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_backend_Juni\resources\views/mcustomer/edit.blade.php ENDPATH**/ ?>