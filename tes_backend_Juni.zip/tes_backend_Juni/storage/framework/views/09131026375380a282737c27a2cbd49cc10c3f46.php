
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">Show Page</div>
  <div class="card-body">
  
        <div class="card-body">
        <h5 class="card-title">Nama : <?php echo e($mcustomer2->nama); ?></h5>
        <p class="card-text">Alamat : <?php echo e($mcustomer2->alamat); ?></p>
        <p class="card-text">Tanggal Lahir : <?php echo e($mcustomer2->tanggal_lahir); ?></p>
  </div>
      
    </hr>
  
  </div>
</div>
<?php echo $__env->make('mcustomer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_backend_Juni\resources\views/mcustomer/show.blade.php ENDPATH**/ ?>